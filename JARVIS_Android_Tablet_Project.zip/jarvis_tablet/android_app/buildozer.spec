[app]
title = JARVIS
package.name = jarvistablet
package.domain = com.excelxyz
source.dir = .
source.include_exts = py,png,jpg,kv
version = 1.0.0
requirements = python3,kivy,requests,pyjnius
orientation = portrait
fullscreen = 1
android.permissions = INTERNET,RECORD_AUDIO
android.api = 35
android.ndk = 27c
android.minapi = 23
android.archs = arm64-v8a
android.enable_androidx = True
p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 1
