import threading, json, os
import requests
from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.graphics import Color, Ellipse, Line
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.utils import get_color_from_hex
from jarvis_config import API_BASE_URL

ANDROID = False
try:
    from jnius import autoclass, PythonJavaClass, java_method
    from android.permissions import request_permissions, Permission
    ANDROID = True
except Exception:
    pass

class Orb(Label):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.text = ""
        self.size_hint = (None, None)
        self.size = (dp(210), dp(210))
        self.bind(pos=self.draw_orb, size=self.draw_orb)
        self.phase = 0

    def draw_orb(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(0.02, 0.08, 0.16, 1)
            Ellipse(pos=self.pos, size=self.size)
            Color(0.1, 0.75, 1, 0.16)
            Ellipse(pos=(self.x+dp(8), self.y+dp(8)), size=(self.width-dp(16), self.height-dp(16)))
            Color(0.15, 0.8, 1, 0.9)
            Line(circle=(self.center_x, self.center_y, self.width*0.39), width=1.5)
            Color(0.35, 0.9, 1, 0.8)
            Ellipse(pos=(self.center_x-dp(37), self.center_y-dp(37)), size=(dp(74), dp(74)))
            Color(0.65, 0.96, 1, 0.95)
            Ellipse(pos=(self.center_x-dp(15), self.center_y-dp(15)), size=(dp(30), dp(30)))

class JarvisApp(App):
    def build(self):
        self.title = "JARVIS"
        self.listening = False
        self.speech = None
        self.tts = None
        root = BoxLayout(orientation="vertical", padding=dp(18), spacing=dp(10))
        root.canvas.before.add(Color(*get_color_from_hex("#050B18")))
        with root.canvas.before:
            from kivy.graphics import Rectangle
            self.bg = Rectangle(pos=root.pos, size=root.size)
        root.bind(pos=self._bg_update, size=self._bg_update)

        title = Label(text="[b]J.A.R.V.I.S[/b]", markup=True, font_size="26sp",
                      color=get_color_from_hex("#75DFFF"), size_hint_y=None, height=dp(48))
        root.add_widget(title)
        self.status = Label(text="INITIALIZING", color=(0.55,0.85,1,1), size_hint_y=None, height=dp(28))
        root.add_widget(self.status)
        holder = BoxLayout(size_hint_y=None, height=dp(235), padding=dp(8))
        holder.add_widget(Label())
        self.orb = Orb()
        holder.add_widget(self.orb)
        holder.add_widget(Label())
        root.add_widget(holder)
        self.transcript = Label(text="Say “Hey Jarvis” or tap the orb.", color=(0.85,0.92,1,1),
                                halign="center", valign="middle", size_hint_y=1)
        self.transcript.bind(size=lambda w,s: setattr(w,"text_size",s))
        root.add_widget(self.transcript)
        self.input = TextInput(hint_text="Or type a command…", multiline=False, size_hint_y=None, height=dp(48))
        root.add_widget(self.input)
        row = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8))
        self.listen_btn = Button(text="START LISTENING", background_color=(0.04,0.45,0.7,1))
        self.listen_btn.bind(on_release=lambda *_: self.start_listening())
        row.add_widget(self.listen_btn)
        send = Button(text="SEND", size_hint_x=.35, background_color=(0.08,0.35,0.5,1))
        send.bind(on_release=lambda *_: self.send_text(self.input.text))
        row.add_widget(send)
        root.add_widget(row)
        self._init_android()
        return root

    def _bg_update(self, widget, value):
        self.bg.pos = widget.pos; self.bg.size = widget.size

    def _init_android(self):
        if not ANDROID:
            self.status.text = "DEMO MODE — build on Android for voice"
            return
        try:
            request_permissions([Permission.RECORD_AUDIO, Permission.INTERNET])
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            self.activity = PythonActivity.mActivity
            self.SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
            self.Intent = autoclass('android.content.Intent')
            self.RecognizerIntent = autoclass('android.speech.RecognizerIntent')
            self.Locale = autoclass('java.util.Locale')
            self.TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
            self.tts = self.TextToSpeech(self.activity, None)
            self.listener = self._make_listener()
            self.recognizer = self.SpeechRecognizer.createSpeechRecognizer(self.activity)
            self.recognizer.setRecognitionListener(self.listener)
            self.status.text = "READY — SAY HEY JARVIS"
        except Exception as e:
            self.status.text = "VOICE SETUP ERROR"

    def _make_listener(self):
        app = self
        class Listener(PythonJavaClass):
            __javainterfaces__ = ['android/speech/RecognitionListener']
            __javacontext__ = 'app'
            @java_method('(Landroid/os/Bundle;)V')
            def onReadyForSpeech(self, params): Clock.schedule_once(lambda dt: app._set_status("LISTENING"))
            @java_method('(Landroid/os/Bundle;)V')
            def onBeginningOfSpeech(self): pass
            @java_method('(F)V')
            def onRmsChanged(self, rms): pass
            @java_method('([B)V')
            def onBufferReceived(self, buffer): pass
            @java_method('()V')
            def onEndOfSpeech(self): pass
            @java_method('(I)V')
            def onError(self, error):
                Clock.schedule_once(lambda dt: app._restart_listening(), 1.0)
            @java_method('(Landroid/os/Bundle;)V')
            def onResults(self, results):
                arr = results.getStringArrayList(app.SpeechRecognizer.RESULTS_RECOGNITION)
                phrase = str(arr.get(0)) if arr and arr.size() else ""
                Clock.schedule_once(lambda dt: app._heard(phrase))
            @java_method('(Landroid/os/Bundle;)V')
            def onPartialResults(self, partial): pass
            @java_method('(ILandroid/os/Bundle;)V')
            def onEvent(self, eventType, params): pass
        return Listener()

    def _set_status(self, value):
        self.status.text = value

    def _recognition_intent(self):
        intent = self.Intent(self.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE_MODEL, self.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        intent.putExtra(self.RecognizerIntent.EXTRA_PARTIAL_RESULTS, True)
        intent.putExtra(self.RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        return intent

    def start_listening(self):
        if not ANDROID:
            self.status.text = "Run this app on Android to use the microphone."
            return
        self.listening = True
        self.listen_btn.text = "STOP LISTENING"
        self._restart_listening()

    def stop_listening(self):
        self.listening = False
        self.listen_btn.text = "START LISTENING"
        try: self.recognizer.cancel()
        except: pass
        self.status.text = "PAUSED"

    def _restart_listening(self):
        if not self.listening: return
        try: self.recognizer.startListening(self._recognition_intent())
        except: Clock.schedule_once(lambda dt: self._restart_listening(), 2)

    def _heard(self, phrase):
        if not self.listening: return
        p = (phrase or "").strip()
        if not p:
            self._restart_listening(); return
        low = p.lower()
        if "hey jarvis" in low or "jarvis" == low:
            command = low.replace("hey jarvis", "").replace("jarvis", "").strip(" ,")
            self.status.text = "WAKE WORD DETECTED"
            if command:
                self._process(command)
            else:
                self.speak("Yes, how can I help?")
                self._restart_listening()
        else:
            # In wake-word mode, ignore unrelated speech and keep waiting.
            self._restart_listening()

    def send_text(self, text):
        if text.strip():
            self._process(text.strip())
            self.input.text = ""

    def _process(self, text):
        self.status.text = "THINKING..."
        self.transcript.text = "You: " + text
        self.orb.opacity = .65
        Animation(opacity=1, duration=.5).start(self.orb)
        threading.Thread(target=self._api_call, args=(text,), daemon=True).start()

    def _api_call(self, text):
        try:
            base = API_BASE_URL.rstrip("/")
            if "YOUR-HTTPS-BACKEND" in base:
                raise ValueError("Set API_BASE_URL in jarvis_config.py first.")
            low = text.lower()
            if "invoice" in low or "इनवॉइस" in low:
                r = requests.post(base+"/invoice-from-command", json={"command":text}, timeout=90)
                if r.status_code == 200 and r.headers.get("content-type","").startswith("application/pdf"):
                    from datetime import datetime
                    out = os.path.join(App.get_running_app().user_data_dir, "jarvis_invoice.pdf")
                    with open(out, "wb") as f: f.write(r.content)
                    reply = "Your invoice PDF has been created and saved in the app's private storage."
                else:
                    try: reply = r.json().get("detail", "Please provide the customer, item, quantity and price.")
                    except: reply = "I couldn't create that invoice. Please try again."
            elif "email" in low or "ईमेल" in low:
                r = requests.post(base+"/draft-email", json={"context":text,"tone":"Professional"}, timeout=60)
                r.raise_for_status(); reply = r.json()["draft"]
            else:
                r = requests.post(base+"/chat", json={"message":text}, timeout=60)
                r.raise_for_status(); reply = r.json()["reply"]
            Clock.schedule_once(lambda dt: self._show_reply(reply))
        except Exception as e:
            Clock.schedule_once(lambda dt: self._show_reply("I couldn't connect to my AI service. Check the backend URL and connection."))

    def _show_reply(self, reply):
        self.transcript.text = "JARVIS: " + reply
        self.status.text = "SPEAKING"
        self.speak(reply)

    def speak(self, text):
        if ANDROID and self.tts:
            try:
                self.tts.speak(text, 0, None, "jarvis_utterance")
            except: pass
        self.status.text = "READY — SAY HEY JARVIS" if self.listening else "READY"

    def on_stop(self):
        self.listening = False
        try:
            if self.recognizer: self.recognizer.destroy()
            if self.tts: self.tts.shutdown()
        except: pass

if __name__ == "__main__":
    JarvisApp().run()
