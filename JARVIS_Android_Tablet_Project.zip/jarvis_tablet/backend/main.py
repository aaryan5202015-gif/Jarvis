import os, io, uuid
from datetime import date
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from openai import OpenAI
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

app = FastAPI(title="JARVIS AI Backend", version="1.0.0")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY")) if os.environ.get("OPENAI_API_KEY") else None

def ai_client():
    if client is None:
        raise HTTPException(503, "Backend is missing OPENAI_API_KEY.")
    return client

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)

class EmailRequest(BaseModel):
    context: str = Field(min_length=1, max_length=8000)
    tone: str = "Professional"

class InvoiceItem(BaseModel):
    description: str
    quantity: float = Field(gt=0)
    unit_price: float = Field(ge=0)

class InvoiceRequest(BaseModel):
    business_name: str
    customer_name: str
    items: List[InvoiceItem]
    invoice_number: Optional[str] = None
    currency: str = "INR"
    notes: Optional[str] = None

@app.get("/health")
def health():
    return {"status": "ok", "service": "JARVIS"}

@app.post("/chat")
def chat(req: ChatRequest):
    response = ai_client().chat.completions.create(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini"),
        messages=[
            {"role": "system", "content": (
                "You are JARVIS, a helpful voice assistant. Reply naturally and concisely. "
                "The user may speak Hindi, English, or Hinglish; reply in the same language. "
                "Do not claim to have performed actions outside this server. "
                "For financial, invoice, or email content, remind the user to review important details."
            )},
            {"role": "user", "content": req.message}
        ],
        temperature=0.6,
    )
    return {"reply": response.choices[0].message.content or "I couldn't prepare a reply."}

@app.post("/draft-email")
def draft_email(req: EmailRequest):
    response = ai_client().chat.completions.create(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini"),
        messages=[
            {"role": "system", "content": "Draft an email only. Never claim it has been sent. Keep it clear and ready for human review."},
            {"role": "user", "content": f"Tone: {req.tone}\nDraft an email reply based on this context:\n{req.context}"}
        ],
        temperature=0.5,
    )
    return {"draft": response.choices[0].message.content or ""}


class InvoiceCommand(BaseModel):
    command: str = Field(min_length=1, max_length=4000)

@app.post("/invoice-from-command")
def invoice_from_command(req: InvoiceCommand):
    """Extract invoice fields from a natural-language voice command, then create its PDF."""
    raw = ai_client().chat.completions.create(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini"),
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": (
                "Extract invoice data from the user's command. Return JSON with keys "
                "business_name, customer_name, currency, items, notes. Each item must have "
                "description, quantity, unit_price. Use INR if currency is not stated. "
                "If required information is missing, use an empty string for names and an empty "
                "items array. Never invent prices or quantities."
            )},
            {"role": "user", "content": req.command}
        ],
        temperature=0,
    )
    import json
    try:
        data = json.loads(raw.choices[0].message.content or "{}")
        invoice = InvoiceRequest(**data)
    except Exception as exc:
        raise HTTPException(422, "I couldn't understand all invoice details. Please state the customer, item, quantity and price.") from exc
    if not invoice.business_name or not invoice.customer_name or not invoice.items:
        raise HTTPException(422, "Please provide your business name, customer name, item description, quantity and unit price.")
    return create_invoice(invoice)

@app.post("/invoice")
def create_invoice(req: InvoiceRequest):
    if not req.items:
        raise HTTPException(400, "At least one invoice item is required.")
    inv_no = req.invoice_number or f"JRV-{date.today():%Y%m%d}-{uuid.uuid4().hex[:5].upper()}"
    subtotal = sum(x.quantity * x.unit_price for x in req.items)
    buf = io.BytesIO()
    pdf = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    y = height - 55
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(45, y, "INVOICE")
    y -= 30
    pdf.setFont("Helvetica", 10)
    pdf.drawString(45, y, f"Invoice No: {inv_no}")
    pdf.drawRightString(width - 45, y, f"Date: {date.today().isoformat()}")
    y -= 28
    pdf.setFont("Helvetica-Bold", 11); pdf.drawString(45, y, "From")
    pdf.drawString(310, y, "Bill To")
    y -= 17
    pdf.setFont("Helvetica", 10)
    pdf.drawString(45, y, req.business_name[:55])
    pdf.drawString(310, y, req.customer_name[:55])
    y -= 38
    pdf.setFont("Helvetica-Bold", 9)
    pdf.drawString(45, y, "Description")
    pdf.drawRightString(365, y, "Qty")
    pdf.drawRightString(445, y, "Rate")
    pdf.drawRightString(width - 45, y, "Amount")
    y -= 8; pdf.line(45, y, width - 45, y); y -= 18
    pdf.setFont("Helvetica", 9)
    for item in req.items:
        if y < 100:
            pdf.showPage(); y = height - 60; pdf.setFont("Helvetica", 9)
        amount = item.quantity * item.unit_price
        pdf.drawString(45, y, item.description[:48])
        pdf.drawRightString(365, y, f"{item.quantity:g}")
        pdf.drawRightString(445, y, f"{item.unit_price:,.2f}")
        pdf.drawRightString(width - 45, y, f"{amount:,.2f}")
        y -= 19
    y -= 8; pdf.line(330, y, width - 45, y); y -= 22
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawRightString(width - 45, y, f"Total: {req.currency} {subtotal:,.2f}")
    if req.notes:
        y -= 35; pdf.setFont("Helvetica", 9); pdf.drawString(45, y, f"Notes: {req.notes[:100]}")
    pdf.save(); buf.seek(0)
    headers = {"Content-Disposition": f'attachment; filename="invoice-{inv_no}.pdf"'}
    return StreamingResponse(buf, media_type="application/pdf", headers=headers)
